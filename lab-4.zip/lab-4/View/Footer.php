<div style="width:100%; height:100px; border:1px solid #000;">

	<?php
		echo "<p> Copyright &copy; Ukile 2022";
	?>

</div>