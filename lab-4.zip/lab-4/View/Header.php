<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=2">
	<title></title>
</head>
<body>
	<div style="width:auto; height:180px; border:1px solid #000;">
	<a href="/Mid_Work/Home.php">
		
	</a>
		
		<div style="float: right; margin-top: 60px; margin-right: 10px; font-size: 20px">
			<a href="/Mid_Work/Home.php">Home</a> |
			<a href="/Mid_Work/View/Login.php">Sign In</a> |
			<a href="/Mid_Work/View/Regdet.php">Sign Up</a>
		</div>		
	</div>
</body>
</html>